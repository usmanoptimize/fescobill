    document.getElementById('checkBill').onclick = function() {
        window.open('https://fescobills.net.pk', '_self');
    };